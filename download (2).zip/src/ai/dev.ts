import { config } from 'dotenv';
config();

import '@/ai/flows/echoes-narrator-facts.ts';